package com.example.petclinic.service;

import com.example.petclinic.model.Pet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class PetService {

    public static final Logger log = LoggerFactory.getLogger(PetService.class);

    RestTemplate restTemplate;

    public PetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Pet add(Pet pet) {
        URI uri = URI.create("http://localhost:9092/petapi/pet/addPet");

        Pet response = restTemplate.postForObject(uri, pet, Pet.class);
        log.info(response.toString());
        return response;
    }

    public Pet get(String name) {
        URI uri = URI.create("http://localhost:9092/petapi/pet/getPet");

        Pet response = restTemplate.getForObject(uri, Pet.class);
        log.info(response.toString());
        return response;
    }

    public Pet modify(Pet pet) {
        URI uri = URI.create("http://localhost:9092/petapi/pet/modifyPet");

        Pet response = restTemplate.getForObject(uri, Pet.class);
        log.info(response.toString());
        return response;
    }

    public Pet delete(Pet pet) {
        URI uri = URI.create("http://localhost:9092/petapi/owner/deletePet");

        Pet response = restTemplate.getForObject(uri, Pet.class);
        log.info(response.toString());
        return response;
    }

    public List<Pet> getAllOwners() {
        URI uri = URI.create("http://localhost:9092/petapi/pet/getAllPets");

        List<Pet> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }
}
