package com.example.petclinic.service;

import com.example.petclinic.model.Owner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class OwnerService {

    public static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner add(Owner owner) {
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        log.info(response.toString());
        return response;
    }

    public Owner get(String name) {
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/getOwner");

        Owner response = restTemplate.getForObject(uri, Owner.class);
        log.info(response.toString());
        return response;
    }

    public Owner modify(Owner owner) {
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/modifyOwner");

        Owner response = restTemplate.getForObject(uri, Owner.class);
        log.info(response.toString());
        return response;
    }

    public Owner delete(Owner owner) {
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/deleteOwner");

        Owner response = restTemplate.getForObject(uri, Owner.class);
        log.info(response.toString());
        return response;
    }

    public List<Owner> getAllOwners() {
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/getAllOwners");

        List<Owner> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }
}
