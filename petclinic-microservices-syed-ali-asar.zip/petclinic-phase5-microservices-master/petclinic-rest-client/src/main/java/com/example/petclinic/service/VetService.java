package com.example.petclinic.service;

import com.example.petclinic.model.Vet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class VetService {

    public static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public VetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Vet add(Vet vet) {
        URI uri = URI.create("http://localhost:9093/vetapi/vet/addVet");

        Vet response = restTemplate.postForObject(uri, vet, Vet.class);
        log.info(response.toString());
        return response;
    }

    public Vet get(String name) {
        URI uri = URI.create("http://localhost:9093/vetapi/vet/getVet");

        Vet response = restTemplate.getForObject(uri, Vet.class);
        log.info(response.toString());
        return response;
    }

    public Vet modify(Vet vet) {
        URI uri = URI.create("http://localhost:9093/vetapi/vet/modifyVet");

        Vet response = restTemplate.getForObject(uri, Vet.class);
        log.info(response.toString());
        return response;
    }

    public Vet delete(Vet owner) {
        URI uri = URI.create("http://localhost:9093/vetapi/vet/deleteVet");

        Vet response = restTemplate.getForObject(uri, Vet.class);
        log.info(response.toString());
        return response;
    }

    public List<Vet> getAllOwners() {
        URI uri = URI.create("http://localhost:9093/vetapi/vet/getAllVets");

        List<Vet> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }
}
