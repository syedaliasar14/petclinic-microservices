package com.example.petclinic.business;

import com.example.petclinic.service.OwnerService;

import java.security.acl.Owner;

public class PetClinicBusinessWorkflow {

    OwnerService ownerService;

    public void runBusiness() {
        // TODO

        // Create Owners
        Owner owner1 ;
        Owner owner2 ;
        Owner owner3 ;
        Owner owner4 ;

        ownerService.saveOwner(owner1);
        ownerService.saveOwner(owner2);
        ownerService.saveOwner(owner3);
        ownerService.saveOwner(owner4);
    }
}
