package com.example.petclinic.service;

import com.example.petclinic.model.Visit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class VisitService {

    public static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public Visit add(Visit visit) {
        URI uri = URI.create("http://localhost:9094/visitapi/visit/addVisit");

        Visit response = restTemplate.postForObject(uri, visit, Visit.class);
        log.info(response.toString());
        return response;
    }

    public Visit get(String name) {
        URI uri = URI.create("http://localhost:9094/visitapi/visit/getVisit");

        Visit response = restTemplate.getForObject(uri, Visit.class);
        log.info(response.toString());
        return response;
    }

    public Visit modify(Visit visit) {
        URI uri = URI.create("http://localhost:9094/visitapi/visit/modifyVisit");

        Visit response = restTemplate.getForObject(uri, Visit.class);
        log.info(response.toString());
        return response;
    }

    public Visit delete(Visit visit) {
        URI uri = URI.create("http://localhost:9094/visitapi/visit/deleteVisit");

        Visit response = restTemplate.getForObject(uri, Visit.class);
        log.info(response.toString());
        return response;
    }

    public List<Visit> getAllOwners() {
        URI uri = URI.create("http://localhost:9094/visitapi/visit/getAllVisits");

        List<Visit> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;
    }
}
